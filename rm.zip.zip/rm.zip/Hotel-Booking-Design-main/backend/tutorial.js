const { sequelize, Sequelize } = require(".");

moduel.exports = (sequelize, Sequelize) => {
    const Tutorial = Sequelize.define("tutorial", {
        title:{
            type: Sequelize.STRING
        },
        description: {
            type:Sequelize.STRING
        },
        published:{
            type: Sequelize.BOOLEAN
        }
    });
    return Tutorial;
};